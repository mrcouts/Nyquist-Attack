#relrenato
latex --src -interaction=nonstopmode Manual\ Mo2D 
# bibtex Manual\ Mo2D 
# latex --src -interaction=nonstopmode Manual\ Mo2D 
latex --src -interaction=nonstopmode Manual\ Mo2D  
pdflatex -synctex=1 Manual\ Mo2D.tex
rm -f *.aux *.log *.blg *.dvi *.ps *.toc *.lot *.lof *.idx *.nlo *.nls *.ilg *.out *.fls
#
#relatorio_renato_maia_matarazzo_orsino
#pdftk relrenato2.pdf paperijmrs.pdf cat output relatorio_renato_maia_matarazzo_orsino_133192_2012-1.pdf
